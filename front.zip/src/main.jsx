import React from 'react';
import Header2 from "./components2/header2.jsx"
function Main() {
    return (
        <>  
            <Header2/>
        </>
    );
}

export default Main;